# LangChain + LangGraph + LangSmith + RAG (SAP HANA Cloud Vector Engine) — Implementation Plan
## bookshop-multi-buildpack (SAP BTP Multi-Buildpack CAP App)

> **Status**: Completed & Deployed to SAP BTP Cloud Foundry Production
> **Target Runtime**: Python 3.10+ (co-located Python worker inside SAP BTP Cloud Foundry)
> **Target Database**: SAP HANA Cloud (BTP Trial compatible with native Vector Engine support)
> **Primary AI Architecture**: Zero-Hardcoding BTP Destination Auto-Selection & 4-Destination Failover Cascade

---

## Table of Contents

1. [Overview & Motivation](#1-overview--motivation)
2. [Current Architecture Summary](#2-current-architecture-summary)
3. [Zero-Hardcoding BTP Destination Auto-Selection Engine](#3-zero-hardcoding-btp-destination-auto-selection-engine)
4. [Multi-Model Router & 4-Destination Failover Cascade](#4-multi-model-router--4-destination-failover-cascade)
5. [What Each Tool Does in This Project](#5-what-each-tool-does-in-this-project)
6. [Phase 1 — LangChain Drop-in Replacement](#phase-1--langchain-drop-in-replacement)
7. [Phase 2 — RAG via SAP HANA Cloud Vector Engine (BTP Trial)](#phase-2--rag-via-sap-hana-cloud-vector-engine-btp-trial)
8. [Phase 3 — LangGraph Agentic Workflow](#phase-3--langgraph-agentic-workflow)
9. [Phase 4 — LangSmith Observability](#phase-4--langsmith-observability)
10. [Testing Plan & HTTP Request Suite](#10-testing-plan--http-request-suite)

---

## 3. Zero-Hardcoding BTP Destination Auto-Selection Engine

Implemented in [`srv/ai-destination.js`](file:///Users/kallolchakraborty/Downloads/BookShop-Multibuildpack/bookshop/srv/ai-destination.js):
- Uses `@sap-cloud-sdk/connectivity` to auto-discover destinations configured in SAP BTP Cockpit.
- Automatically extracts `baseUrl`, `apiKey`, and `model` directly from the Destination properties object at runtime.

---

## 4. Multi-Model Router & 4-Destination Failover Cascade

Implemented in [`python/agent/llm_router.py`](file:///Users/kallolchakraborty/Downloads/BookShop-Multibuildpack/bookshop/python/agent/llm_router.py):

| Priority Rank | BTP Cockpit Destination Name | Target Model ID | Role in Failover Chain |
|---------------|------------------------------|-----------------|------------------------|
| **Priority 1 (Primary)** | `google-diffusiongemma-26b-a4b-it` | `google/diffusiongemma-26b-a4b-it` | Primary Model (First Choice) |
| **Priority 2** | `mistralai-mistral-nemotron` | `mistralai/mistral-nemotron` | Secondary Model |
| **Priority 3** | `meta-llama-3-3-70b-instruct` | `meta/llama-3.3-70b-instruct` | Tertiary Model |
| **Priority 4 (Fallback)** | `z-ai-glm-5-2` | `z-ai/glm-5.2` | Designated Fallback Model |
