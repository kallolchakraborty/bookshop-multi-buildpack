"""Bookshop Agent package initialization."""
