"""Evaluation package initialization."""
