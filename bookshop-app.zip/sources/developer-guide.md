# Developer Guide & Anthropic AI Architecture Manual

## Overview & Architecture

The **SAP BTP Bookshop Multi-Buildpack** application is an enterprise reference architecture co-locating an SAP CAP Node.js edge gateway with an **Anthropic-Architected LangGraph AI Agent & SAP HANA Cloud REAL_VECTOR Engine** inside a single Cloud Foundry container droplet (512 MB).

---

## Key AI Architecture Subsystems

### 1. LangChain & LangGraph Stateful Agent Pipeline
- **Implementation**: `python/agent/graph.py` and `python/agent/nodes.py`.
- **StateGraph**: Maintains stateful memory (`chat_history`, `user_intent`, `catalog_context`).
- **Nodes**:
  - `input_guardrails`: Detects prompt injection signatures and redacts PII/secrets.
  - `redis_cache`: Checks Redis for cached completions (< 5ms response time).
  - `hana_rag`: Vector search over SAP HANA Cloud `Vector(1536)` embeddings.
  - `llm_router`: Executes multi-model failover cascade.
  - `output_guardrails`: Redacts competitor names and validates groundedness.

### 2. Multi-Model Router & Failover Cascade
- **Implementation**: `python/agent/llm_router.py` & `srv/ai-destination.js`.
- **Priority Cascade**:
  <div class="failover-cascade">
    <span class="fc-step p1">P1 · google/diffusiongemma-26b-a4b-it</span>
    <span class="fc-arrow">→</span>
    <span class="fc-step p2">P2 · google/gemma-4-31b-it</span>
    <span class="fc-arrow">→</span>
    <span class="fc-step p3">P3 · z-ai/glm-5.2</span>
    <span class="fc-arrow">→</span>
    <span class="fc-step fallback">Fallback · mistralai/mistral-nemotron</span>
  </div>

### 3. Enterprise Redis Prompt Caching
- **Implementation**: `python/agent/cache.py`.
- Auto-binds to SAP BTP `redis-instance` via `VCAP_SERVICES`.
- Generates SHA-256 signatures for `(model:prompt)` keys with **< 5ms** hit response times.

### 4. SAP HANA Cloud REAL_VECTOR Engine
- **Implementation**: `python/agent/rag.py`.
- Performs 1536-dimensional vector embedding search using native SAP HANA Cloud `COSINE_SIMILARITY()` and `TO_REAL_VECTOR()`.

---

## Getting Started Locally

```bash
# 1. Install Node.js dependencies
npm install

# 2. Start the application locally
npm start

# 3. Test HTTP Endpoints via REST Client
# Open test/http-requests.http in VS Code / Antigravity IDE and run requests!

# 4. Execute Automated Test Suite
npm run test:ai
```

---

## System Probes & Health Checks
- **Health Probe**: `http://localhost:4004/healthz` $\rightarrow$ `{"status":"OK"}`
- **Readiness Probe**: `http://localhost:4004/readyz` $\rightarrow$ `{"status":"READY","python":"OK"}`
